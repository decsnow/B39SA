% create a random column vector with 20 elements between 0 and 1
r = rand(20, 1)

% scale and shift the elements to be between -2 and 5
r = -2 + 7 * r

% plot the results
plot(r(1:10), 'r'); hold on;
plot(r(11:20), 'b');
plot(r(2:2:20), 'k');

% display the legend

legend('first 10 elements', 'last 10 elements', 'the even elements');